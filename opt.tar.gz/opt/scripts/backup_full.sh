#!/bin/bash

# ---------- Función de ayuda ----------
function mostrar_ayuda() {
    echo "Uso: $0 -origen <directorio> -destino <directorio> [-help]"
    echo
    echo "Parámetros:"
    echo "  -origen     Directorio a backupear (ej: /var/log)"
    echo "  -destino    Directorio destino del backup (ej: /backup_dir)"
    echo "  -help       Muestra esta ayuda"
    echo
    echo "Ejemplo:"
    echo "  $0 -origen /var/log -destino /backup_dir"
    exit 0
}

# ---------- Validación de argumentos ----------
if [[ "$1" == "-help" || $# -eq 0 ]]; then
    mostrar_ayuda
fi

while [[ $# -gt 0 ]]; do
    case "$1" in
        -origen)
            ORIGEN="$2"
            shift 2
            ;;
        -destino)
            DESTINO="$2"
            shift 2
            ;;
        *)
            echo "Error: Argumento no reconocido: $1"
            mostrar_ayuda
            ;;
    esac
done

# ---------- Validaciones de parámetros ----------
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "Error: Debes especificar origen y destino."
    mostrar_ayuda
fi

if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no está montado."
    exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no está montado."
    exit 1
fi

# ---------- Generación del nombre del archivo ----------
FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")
NOMBRE_BKP="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"
ARCHIVO_DESTINO="${DESTINO}/${NOMBRE_BKP}"

# ---------- Ejecución del backup ----------
echo "Iniciando backup de ${ORIGEN}..."
tar -czf "$ARCHIVO_DESTINO" -C "$(dirname "$ORIGEN")" "$NOMBRE_DIR"

if [[ $? -eq 0 ]]; then
    echo "Backup completado correctamente: $ARCHIVO_DESTINO"
else
    echo "Error durante la creación del backup."
    exit 1
fi

exit 0
``````
#!/bin/bash

# ---------- Función de ayuda ----------
function mostrar_ayuda() {
    echo "Uso: $0 -origen <directorio> -destino <directorio> [-help]"
    echo
    echo "Parámetros:"
    echo "  -origen     Directorio a backupear (ej: /var/log)"
    echo "  -destino    Directorio destino del backup (ej: /backup_dir)"
    echo "  -help       Muestra esta ayuda"
    echo
    echo "Ejemplo:"
    echo "  $0 -origen /var/log -destino /backup_dir"
    exit 0
}

# ---------- Validación de argumentos ----------
if [[ "$1" == "-help" || $# -eq 0 ]]; then
    mostrar_ayuda
fi

while [[ $# -gt 0 ]]; do
    case "$1" in
        -origen)
            ORIGEN="$2"
            shift 2
            ;;
        -destino)
            DESTINO="$2"
            shift 2
            ;;
        *)
            echo "Error: Argumento no reconocido: $1"
            mostrar_ayuda
            ;;
    esac
done

# ---------- Validaciones de parámetros ----------
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "Error: Debes especificar origen y destino."
    mostrar_ayuda
fi

if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no está montado."
    exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio de destino '$DESTINO' no existe o no está montado."
    exit 1
fi

# ---------- Generación del nombre del archivo ----------
FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")
NOMBRE_BKP="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"
ARCHIVO_DESTINO="${DESTINO}/${NOMBRE_BKP}"

# ---------- Ejecución del backup ----------
echo "Iniciando backup de ${ORIGEN}..."
tar -czf "$ARCHIVO_DESTINO" -C "$(dirname "$ORIGEN")" "$NOMBRE_DIR"

if [[ $? -eq 0 ]]; then
    echo "Backup completado correctamente: $ARCHIVO_DESTINO"
else
    echo "Error durante la creación del backup."
    exit 1
fi

exit 0

