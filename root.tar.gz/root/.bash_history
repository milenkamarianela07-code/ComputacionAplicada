 poweroff
 poweroff
passwd
vim
vim /etc/hostname
vim /etc/hosts
reboot
dpkg-reconfigure keyboard-configuration
reboot
exit
cat
cat /var/log/apache2/error.log 
[200~sudo apt install php libapache2-mod-php php-mysql php-cli php-curl php-gd php-xml php-mbstring -y~
sudo apt install php libapache2-mod-php php-mysql php-cli php-curl php-gd php-xml php-mbstring -y
service apache2 restart
rm /var/www/html/index.html 
ls
pwd
ls - la
ls -la
mkdir .ssh
cd .ssh
mv ../clave_publica.pub .
mv ../clave_privada.txt .
ls
mv  clave_privada.txt c1
mv clave_publica.pub  c1.pub
ls -la 
chmod 400 c1
ls
ls -la
chmod 600 c1
ls -la
vim /etc/ssh
service ssh
service ssh restart
mv 
cat c1.pub
cat c1.pub>authorized_keys
vim /etc/ssh/sshd_config
cd
apt update

apt  install php libapache2-mod-php
a2enmod php7.4 
service apache2 restart
ls /var/www/html/index.html .
cat /var/log/apache2/error.log
apt install mariadb-server mariadb-client 
systemctl enable mariadb
systemctl start  mariadb
ls
mysql -uroot < db.sql 
mysql -uroot  
ip a
ip r l
sudo nano /etc/network/interfaces
sudo vim  /etc/network/interfaces
sudo systemctl restart networking
ip a l
reboot
fdisk -l
fdisk /dev/sdc
fdisk -l
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir
mkdir -p /backup_dir
vim /etc/fstab
mount -a
df -h
cat /etc/fstab 
vim /etc/apache2/sites-enabled/
service apache2 restarte
service apache2 restart
mv /var/www/html/* /www_dir
ls -la /
ls -la /www_dir
ls -la /var/www/html
cat /var/log/apache2/error.log
chmod 755 /www_dir
chown -R www-data:www-data /www_dir
cat /var/log/apache2/error.log
vim /etc/apache2/sites-enabled/000-default.conf 
service apache2 restart
ls /proc
ln -s /proc/partitions /opt/particion 
cat /opt/particion
reboot
reboot
